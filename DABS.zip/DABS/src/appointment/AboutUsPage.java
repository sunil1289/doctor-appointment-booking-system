package appointment;

;

import javax.swing.*;
import java.awt.*;

public class AboutUsPage extends JFrame {
    AboutUsPage() {
        setTitle("About Us");
        setSize(1900, 1900);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);


        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        JLabel label = new JLabel("<html><h1>About Us</h1><p>We are a medical group dedicated to providing the best healthcare.</p></html>", SwingConstants.CENTER);
        panel.add(label, BorderLayout.CENTER);

        add(panel);
        setVisible(true);
    }
}
