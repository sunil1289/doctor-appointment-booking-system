package appointment;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import java.awt.*;
import java.sql.*;

public class AdminDashboard extends JFrame {
    private JTable appointmentTable;
    private DefaultTableModel tableModel;
    private Connection connection;

    public AdminDashboard() {
        // Frame setup
        setTitle("Admin Dashboard");
        setSize(2000, 1200);  // Increased frame size
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Welcome Label with large font
        JLabel welcomeLabel = new JLabel("Welcome to the Admin Dashboard", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24)); // Large font size
        add(welcomeLabel, BorderLayout.NORTH);

        // Initialize table and load data
        tableModel = new DefaultTableModel(
                new String[]{"ID", "Name", "Contact", "Address", "Email", "Doctor", "Specialty", "Date", "Time", "Delete"},
                0
        );
        appointmentTable = new JTable(tableModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 9; // Only make "Delete" column editable (for button press)
            }
        };

        // Set table font to a larger size
        appointmentTable.setFont(new Font("Arial", Font.PLAIN, 18));  // Table font size
        appointmentTable.setRowHeight(30);  // Row height to make the text more readable

        // Add a button to each row in the "Delete" column
        appointmentTable.getColumnModel().getColumn(9).setCellRenderer(new ButtonRenderer());
        appointmentTable.getColumnModel().getColumn(9).setCellEditor(new ButtonEditor(new JCheckBox()));

        JScrollPane scrollPane = new JScrollPane(appointmentTable);
        add(scrollPane, BorderLayout.CENTER);

        // Button panel with larger buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        JButton addButton = new JButton("Add Appointment");
        JButton logoutButton = new JButton("Logout");

        // Set larger font for buttons
        addButton.setFont(new Font("Arial", Font.PLAIN, 18));
        logoutButton.setFont(new Font("Arial", Font.PLAIN, 18));

        buttonPanel.add(addButton);
        buttonPanel.add(logoutButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Button actions
        addButton.addActionListener(e -> addAppointment());
        logoutButton.addActionListener(e -> {
            dispose();
            new AdminLoginPage();
        });

        // Database connection and load data
        connectToDatabase();
        if (connection != null) {
            loadAppointments();
        }

        setVisible(true);
    }

    private void connectToDatabase() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/dabs", "root", "");
            System.out.println("Database connected successfully.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            connection = null; // Explicitly set to null if connection fails
        }
    }

    private void loadAppointments() {
        if (connection == null) {
            return;
        }
        tableModel.setRowCount(0); // Clear existing data
        String query = "SELECT * FROM appointments";
        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                tableModel.addRow(new Object[]{
                        resultSet.getInt("id"),
                        resultSet.getString("name"),
                        resultSet.getString("contact"),
                        resultSet.getString("address"),
                        resultSet.getString("email"),
                        resultSet.getString("doctor"),
                        resultSet.getString("specialty"),
                        resultSet.getDate("appointment_date"),
                        resultSet.getTime("appointment_time"),
                        "Delete" // Text for delete button in the last column
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading appointments: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addAppointment() {
        JTextField nameField = new JTextField();
        JTextField contactField = new JTextField();
        JTextField addressField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField doctorField = new JTextField();
        JTextField specialtyField = new JTextField();
        JTextField dateField = new JTextField("YYYY-MM-DD");
        JTextField timeField = new JTextField("HH:MM:SS");

        JPanel panel = new JPanel(new GridLayout(8, 2));
        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Contact:"));
        panel.add(contactField);
        panel.add(new JLabel("Address:"));
        panel.add(addressField);
        panel.add(new JLabel("Email:"));
        panel.add(emailField);
        panel.add(new JLabel("Doctor:"));
        panel.add(doctorField);
        panel.add(new JLabel("Specialty:"));
        panel.add(specialtyField);
        panel.add(new JLabel("Appointment Date:"));
        panel.add(dateField);
        panel.add(new JLabel("Appointment Time:"));
        panel.add(timeField);

        int result = JOptionPane.showConfirmDialog(this, panel, "Add Appointment", JOptionPane.OK_CANCEL_OPTION);
        if (result == JOptionPane.OK_OPTION) {
            try {
                String query = "INSERT INTO appointments (name, contact, address, email, doctor, specialty, appointment_date, appointment_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement statement = connection.prepareStatement(query)) {
                    statement.setString(1, nameField.getText());
                    statement.setString(2, contactField.getText());
                    statement.setString(3, addressField.getText());
                    statement.setString(4, emailField.getText());
                    statement.setString(5, doctorField.getText());
                    statement.setString(6, specialtyField.getText());
                    statement.setDate(7, Date.valueOf(dateField.getText()));
                    statement.setTime(8, Time.valueOf(timeField.getText()));
                    statement.executeUpdate();
                    loadAppointments();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error adding appointment: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void deleteAppointment(int id) {
        try {
            String query = "DELETE FROM appointments WHERE id = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, id);
                statement.executeUpdate();
                loadAppointments();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error deleting appointment: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new AdminDashboard();
    }

    // Button Renderer class to display "Delete" button
    class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setText("Delete");
            setFont(new Font("Arial", Font.PLAIN, 18));
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            return this;
        }
    }

    // Button Editor class to handle the click event and call delete method
    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private int row;

        public ButtonEditor(JCheckBox checkBox) {
            super(checkBox);
            button = new JButton();
            button.setFont(new Font("Arial", Font.PLAIN, 18));
            button.addActionListener(e -> deleteRow());
        }

        @Override
        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            this.row = row;
            button.setText("Delete");
            return button;
        }

        private void deleteRow() {
            int id = (int) appointmentTable.getValueAt(row, 0); // Get the appointment ID from the selected row
            deleteAppointment(id);
        }
    }
}
