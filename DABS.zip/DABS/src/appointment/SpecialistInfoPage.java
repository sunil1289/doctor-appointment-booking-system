package appointment;

import javax.swing.*;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class SpecialistInfoPage extends JFrame {

    private JTextArea infoTextArea;
    private Map<String, String> specialistDefinitions = new HashMap<>();
    private Map<String, String[]> specialistDoctors = new HashMap<>();
    private Map<String, String[]> doctorCharges = new HashMap<>();
    private JButton backButton;

    public SpecialistInfoPage() {
        setTitle("Specialist Information");
        setSize(2100, 1000);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());


        populateSpecialistInfo();


        infoTextArea = new JTextArea();
        infoTextArea.setFont(new Font("Arial", Font.PLAIN, 40));
        infoTextArea.setEditable(false);
        displaySpecialistInfo("Cardiology");

        JComboBox<String> specialtyComboBox = new JComboBox<>(specialistDefinitions.keySet().toArray(new String[0]));
        specialtyComboBox.addActionListener(e -> {
            String selectedSpecialty = (String) specialtyComboBox.getSelectedItem();
            if (selectedSpecialty != null) {
                displaySpecialistInfo(selectedSpecialty);
            }
        });


        backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.BOLD, 20));
        backButton.addActionListener(e -> {
            new DoctorViewPage();
            dispose();
        });

        JPanel northPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        northPanel.add(new JLabel("Select Specialty:"));
        northPanel.add(specialtyComboBox);

        add(northPanel, BorderLayout.NORTH);
        add(new JScrollPane(infoTextArea), BorderLayout.CENTER);
        add(backButton, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void populateSpecialistInfo() {
        specialistDefinitions.put("Cardiology", "Cardiology is the study and treatment of heart conditions.");
        specialistDefinitions.put("Dermatology", "Dermatology is the branch of medicine dealing with the skin.");
        specialistDefinitions.put("Neurology", "Neurology deals with disorders of the nervous system.");
        specialistDefinitions.put("Obstetrician", "Obstetrics focuses on pregnancy and childbirth.");
        specialistDefinitions.put("Dermatologist", "Dermatologists specialize in skin disorders.");
        specialistDefinitions.put("Endocrinologist", "Endocrinology deals with hormones and glands.");
        specialistDefinitions.put("Gastroenterologist", "Gastroenterology focuses on the digestive system.");
        specialistDefinitions.put("Immunologist", "Immunology studies the immune system.");
        specialistDefinitions.put("Psychiatrist", "Psychiatry is the study of mental disorders.");
        specialistDefinitions.put("Ophthalmologist", "Ophthalmology deals with eye health and diseases.");

        specialistDoctors.put("Cardiology", new String[]{"Dr. HARIKIRSHNA", "Dr. Vikram"});
        specialistDoctors.put("Dermatology", new String[]{"Dr. SHAYAM", "Dr. Monika"});
        specialistDoctors.put("Neurology", new String[]{"Dr. Nabin", "Dr. Rita"});
        specialistDoctors.put("Obstetrician", new String[]{"Dr. Divya"});
        specialistDoctors.put("Dermatologist", new String[]{"Dr. Vikram"});
        specialistDoctors.put("Endocrinologist", new String[]{"Dr. Rita"});
        specialistDoctors.put("Gastroenterologist", new String[]{"Dr. Rabin"});
        specialistDoctors.put("Immunologist", new String[]{"Dr. Monika"});
        specialistDoctors.put("Psychiatrist", new String[]{"Dr. Harit"});
        specialistDoctors.put("Ophthalmologist", new String[]{"Dr. Susant"});

        doctorCharges.put("Dr. HARIKIRSHNA", new String[]{"Consultation: Rs3000", "Follow-up: 1500"});
        doctorCharges.put("Dr. Vikram", new String[]{"Consultation: Rs2000", "Follow-up: 1000"});
        doctorCharges.put("Dr. SHAYAM", new String[]{"Consultation: 1000", "Follow-up: 500"});
        doctorCharges.put("Dr. Monika", new String[]{"Consultation: 1500", "Follow-up: 550"});
        doctorCharges.put("Dr. Nabin", new String[]{"Consultation: 1200", "Follow-up: Rs1000"});
        doctorCharges.put("Dr. Rita", new String[]{"Consultation: 2000", "Follow-up: 1000"});
        doctorCharges.put("Dr. Divya", new String[]{"Consultation: Rs2000", "Follow-up: 1200"});
        doctorCharges.put("Dr. Rabin", new String[]{"Consultation: Rs1500", "Follow-up: Rs500"});
        doctorCharges.put("Dr. Harit", new String[]{"Consultation: Rs1000", "Follow-up: Rs1150"});
        doctorCharges.put("Dr. Susant", new String[]{"Consultation: RS1200", "Follow-up: Rs1200"});
    }

    private void displaySpecialistInfo(String specialty) {
        String definition = specialistDefinitions.get(specialty);
        StringBuilder doctorsInfo = new StringBuilder("Doctors:\n");

        for (String doctor : specialistDoctors.get(specialty)) {
            doctorsInfo.append(doctor).append("\n");
            String[] charges = doctorCharges.get(doctor);
            for (String charge : charges) {
                doctorsInfo.append("  - ").append(charge).append("\n");
            }
        }

        infoTextArea.setText(definition + "\n\n" + doctorsInfo.toString());
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SpecialistInfoPage::new);
    }
}
