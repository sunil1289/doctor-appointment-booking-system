package appointment;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Index extends JFrame implements ActionListener {
    JFrame f;
    JLabel l1, l2, l3;
    JButton b1, b2;
    HoverButton aboutUsButton, contactUsButton;

    Index() {
        f = new JFrame("Index Page");
        f.setBackground(Color.white);
        f.setLayout(null);

        l1 = new JLabel();
        l1.setBounds(0, 0, 1900, 1900);
        l1.setLayout(null);

        ImageIcon img = new ImageIcon(ClassLoader.getSystemResource("icon/images.png"));
        Image i1 = img.getImage().getScaledInstance(1900, 1900, Image.SCALE_SMOOTH);
        ImageIcon img1 = new ImageIcon(i1);
        l1.setIcon(img1);

        l2 = new JLabel("S Medical Group");
        l2.setBounds(70, 315, 500, 30);
        l2.setFont(new Font("Arial", Font.BOLD, 44));
        l2.setForeground(Color.BLACK);
        l1.add(l2);

        l3 = new JLabel("Good Health Is The Best Wealth");
        l3.setBounds(90, 345, 500, 30);
        l3.setFont(new Font("Courier", Font.BOLD, 30));
        l3.setForeground(Color.BLACK);
        l1.add(l3);


        b1 = new JButton("Admin");
        b1.setBounds(50, 390, 200, 60);
        b1.setFont(new Font("Arial", Font.BOLD, 40));
        b1.setBackground(Color.black);
        b1.setForeground(Color.white);
        l1.add(b1);

        b2 = new JButton("Patient");
        b2.setBounds(270, 390, 200, 60);
        b2.setFont(new Font("Arial", Font.BOLD, 40));
        b2.setBackground(Color.black);
        b2.setForeground(Color.white);
        l1.add(b2);

        b1.addActionListener(this);
        b2.addActionListener(this);

        aboutUsButton = new HoverButton("About Us", Color.darkGray, Color.lightGray);
        aboutUsButton.setBounds(1600, 20, 150, 40);
        aboutUsButton.addActionListener(this);
        l1.add(aboutUsButton);

        contactUsButton = new HoverButton("Contact Us", Color.darkGray, Color.lightGray);
        contactUsButton.setBounds(1750, 20, 150, 40);
        contactUsButton.addActionListener(this);
        l1.add(contactUsButton);

        f.add(l1);
        f.setSize(2100, 1000);
        f.setLocation(100, 200);
        f.setVisible(true);

        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public void actionPerformed(ActionEvent ae) {
        this.setVisible(false);
        if (ae.getSource() == b1) {
            new AdminLoginPage();
        } else if (ae.getSource() == b2) {
            new PatientLoginPage();
        } else if (ae.getSource() == aboutUsButton) {
            new AboutUsPage();
        } else if (ae.getSource() == contactUsButton) {
            new ContactUsPage();
        }
    }

    public static void main(String[] args) {
        new Index();
    }
}
