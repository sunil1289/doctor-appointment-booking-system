package appointment;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AppointmentFillDetailsPage extends JFrame {
    private JTextField nameField;
    private JTextField contactField;
    private JTextField addressField;
    private JTextField emailField;
    private JButton submitButton;

    private String doctorName;
    private String specialty;
    private String appointmentTime;
    private String appointmentDate;

    public AppointmentFillDetailsPage(String doctorName, String specialty, String appointmentTime, String appointmentDate) {
        this.doctorName = doctorName;
        this.specialty = specialty;
        this.appointmentTime = appointmentTime;
        this.appointmentDate = appointmentDate;

        setTitle("Appointment Fill Details");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        getContentPane().setBackground(new Color(0, 191, 255));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(20, 20, 20, 20);

        addInputFields(gbc);
        addSubmitButton(gbc);

        setVisible(true);
    }

    private void addInputFields(GridBagConstraints gbc) {
        Font labelFont = new Font("Arial", Font.BOLD, 16);
        Font textFieldFont = new Font("Arial", Font.PLAIN, 14);

        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setFont(labelFont);
        add(nameLabel, gbc);
        nameField = new JTextField(20);
        nameField.setFont(textFieldFont);
        gbc.gridx = 1;
        add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel contactLabel = new JLabel("Contact Number:");
        contactLabel.setFont(labelFont);
        add(contactLabel, gbc);
        contactField = new JTextField(20);
        contactField.setFont(textFieldFont);
        gbc.gridx = 1;
        add(contactField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setFont(labelFont);
        add(addressLabel, gbc);
        addressField = new JTextField(20);
        addressField.setFont(textFieldFont);
        gbc.gridx = 1;
        add(addressField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(labelFont);
        add(emailLabel, gbc);
        emailField = new JTextField(20);
        emailField.setFont(textFieldFont);
        gbc.gridx = 1;
        add(emailField, gbc);
    }

    private void addSubmitButton(GridBagConstraints gbc) {
        submitButton = new JButton("Submit");
        submitButton.setFont(new Font("Arial", Font.BOLD, 16));
        submitButton.setBackground(new  Color(230, 230, 250));
        submitButton.setForeground(Color.black);
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submitAppointmentDetails();
            }
        });

        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        add(submitButton, gbc);
    }


    private void submitAppointmentDetails() {
        String sql = "INSERT INTO appointments (name, contact, address, email, doctor, specialty, appointment_date, appointment_time) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Validate email format
            if (!emailField.getText().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
                JOptionPane.showMessageDialog(this, "Invalid email format.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            conn = ConnectionClass.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, nameField.getText());
            pstmt.setString(2, contactField.getText());
            pstmt.setString(3, addressField.getText());
            pstmt.setString(4, emailField.getText());
            pstmt.setString(5, doctorName);
            pstmt.setString(6, specialty);
            pstmt.setString(7, appointmentDate);
            pstmt.setString(8, appointmentTime);
            pstmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Your appointment has been booked!", "Success", JOptionPane.INFORMATION_MESSAGE);

            String message = String.format("Appointment Details:\n" +
                            "Name: %s\nContact: %s\nAddress: %s\nEmail: %s\n" +
                            "Doctor: %s\nSpecialty: %s\nDate: %s\nTime: %s",
                    nameField.getText(), contactField.getText(), addressField.getText(),
                    emailField.getText(), doctorName, specialty, appointmentDate, appointmentTime);
            JOptionPane.showMessageDialog(null, message);
            dispose();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error saving appointment: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            ConnectionClass.closeResources(conn, pstmt);
        }
    }
}