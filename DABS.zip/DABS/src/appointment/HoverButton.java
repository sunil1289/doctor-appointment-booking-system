package appointment;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class HoverButton extends JButton {
    private Color defaultColor;
    private Color hoverColor;

    public HoverButton(String text, Color defaultColor, Color hoverColor) {
        super(text);
        this.defaultColor = defaultColor;
        this.hoverColor = hoverColor;
        setBackground(defaultColor);
        setForeground(Color.white);
        setOpaque(true);
        setBorderPainted(false);
        setFocusPainted(false);

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                setBackground(hoverColor);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                setBackground(defaultColor);
            }
        });
    }
}
