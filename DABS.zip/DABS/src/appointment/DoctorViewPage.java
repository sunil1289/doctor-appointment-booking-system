package appointment;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

public class DoctorViewPage extends JFrame {

    private JComboBox<String> specialtyComboBox;
    private JComboBox<String> doctorComboBox;
    private JComboBox<String> timeComboBox;
    private JSpinner dateSpinner;
    private JButton bookButton;
    private JButton infoButton;
    private JLabel photoLabel;
    private JLabel contactNumberLabel;

    private Map<String, String[]> doctorAvailability = new HashMap<>();
    private Map<String, String> doctorContactNumbers = new HashMap<>();
    private Map<String, String> doctorImagePaths = new HashMap<>();
    private Map<String, String[]> specialtyDoctors = new HashMap<>();

    public DoctorViewPage() {
        setTitle("Doctor View Page");
        setSize(2100, 1100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(50, 30, 10, 10);

        getContentPane().setBackground(new Color(20, 248, 255));


        doctorAvailability.put("Dr. HARIKIRSHNA", new String[]{"10:00 AM", "11:00 AM", "1:00 PM"});
        doctorAvailability.put("Dr. SHAYAM", new String[]{"9:00 AM", "12:00 PM", "3:00 PM"});
        doctorAvailability.put("Dr. Divya", new String[]{"5:00 AM", "10:00 PM", "1:00 PM"});
        doctorAvailability.put("Dr. Vikram", new String[]{"10:00 AM", "12:00 AM", "2:00 PM"});
        doctorAvailability.put("Dr. Monika", new String[]{"1:00 AM", "7:00 AM", "8:00 PM"});
        doctorAvailability.put("Dr. Nabin", new String[]{"12:00 AM", "1:00 AM", "9:00 PM"});
        doctorAvailability.put("Dr. Rabin", new String[]{"1:00 AM", "7:00 AM", "8:00 PM"});
        doctorAvailability.put("Dr. Susant", new String[]{"1:00 AM", "11:00 AM", "9:00 PM"});
        doctorAvailability.put("Dr. Rita", new String[]{"9:00 AM", "3:00 AM", "9:00 PM"});
        doctorAvailability.put("Dr. Harit", new String[]{"9:00 AM", "9:00 AM", "11:00 PM"});

        doctorContactNumbers.put("Dr. HARIKIRSHNA", "+977 9878679089");
        doctorContactNumbers.put("Dr. SHAYAM", "+977 9876534256");
        doctorContactNumbers.put("Dr. Divya", "+977 9879034256");
        doctorContactNumbers.put("Dr. Vikram", "+977 9876578256");
        doctorContactNumbers.put("Dr. Monika", "+977 9869004256");
        doctorContactNumbers.put("Dr. Nabin", "+977 9886930256");
        doctorContactNumbers.put("Dr. Rabin", "+977 967653400");
        doctorContactNumbers.put("Dr. Susant", "+977 9809875776");
        doctorContactNumbers.put("Dr. Rita", "+977 9800534056");
        doctorContactNumbers.put("Dr. Harit", "+977 98790342563");




        doctorImagePaths.put("Dr. HARIKIRSHNA", "src/icon/doctor.jpg");
        doctorImagePaths.put("Dr. SHAYAM", "src/icon/doctor2.jpg");
        doctorImagePaths.put("Dr. HARIKIRSHNA", "src/icon/doctor1.jpg");
        doctorImagePaths.put("Dr. SHAYAM", "src/icon/doctor2.jpg");
        doctorImagePaths.put("Dr. Divya", "src/icon/doctor3.jpg");
        doctorImagePaths.put("Dr. Vikram", "src/icon/doctor4.jpg");
        doctorImagePaths.put("Dr. Monika", "src/icon/doctor5.jpg");
        doctorImagePaths.put("Dr. Nabin", "src/icon/doctor6.jpg");
        doctorImagePaths.put("Dr. Rabin", "src/icon/doctor7.jpg");
        doctorImagePaths.put("Dr. Susant", "src/icon/doctor8.jpg");
        doctorImagePaths.put("Dr. Rita", "src/icon/doctor9.jpg");
        doctorImagePaths.put("Dr. Harit", "src/icon/doctor10.jpg");



        specialtyDoctors.put("Cardiology", new String[]{"Dr. HARIKIRSHNA"});
        specialtyDoctors.put("Dermatology", new String[]{"Dr. SHAYAM"});
        specialtyDoctors.put("Neurology", new String[]{"Dr. Nabin"});
        specialtyDoctors.put("Obstetrician", new String[]{"Dr. Divya"});
        specialtyDoctors.put("Dermatologist", new String[]{"Dr. Vikram"});
        specialtyDoctors.put("Endocrinologist", new String[]{"Dr. Rita"});
        specialtyDoctors.put("Gastroenterologist", new String[]{"Dr. Rabin"});
        specialtyDoctors.put("Immunologist", new String[]{"Dr. Monika"});
        specialtyDoctors.put("Psychiatrist", new String[]{"Dr. Harit"});
        specialtyDoctors.put("Ophthalmologist", new String[]{"Dr.Susant"});




        ImageIcon photoIcon = loadImageAndResize(doctorImagePaths.get("Dr. HARIKIRSHNA"), 150, 150);

        photoLabel = new JLabel(photoIcon);

        contactNumberLabel = new JLabel("Contact: " + doctorContactNumbers.get("Dr. HARIKIRSHNA"));
        contactNumberLabel.setFont(new Font("Arial", Font.BOLD, 24));



        JLabel specialtyLabel = new JLabel("Select Specialty:");
        specialtyLabel.setFont(new Font("Arial", Font.BOLD, 18));
        specialtyComboBox = new JComboBox<>(specialtyDoctors.keySet().toArray(new String[0]));

        JLabel doctorLabel = new JLabel("Select Doctor:");
        doctorLabel.setFont(new Font("Arial", Font.BOLD, 18));
        doctorComboBox = new JComboBox<>();

        JLabel timeLabel = new JLabel("Available Time:");
        timeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        timeComboBox = new JComboBox<>();

        JLabel dateLabel = new JLabel("Booking Date:");
        dateLabel.setFont(new Font("Arial", Font.BOLD, 18));
        dateSpinner = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor dateEditor = new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd");
        dateSpinner.setEditor(dateEditor);

        bookButton = new JButton("Book Appointment");

        bookButton.setEnabled(true);
        bookButton.setBackground(new Color(30, 144, 255));
        bookButton.setForeground(Color.BLACK);
        bookButton.setFont(new Font("Arial", Font.BOLD, 16));
        bookButton.setFocusPainted(false);
        bookButton.setBorder(BorderFactory.createLineBorder(new Color(30, 144, 255), 2));

        infoButton = new JButton("Doctor Specialist Info");
        infoButton.setBackground(new Color(255, 69, 0));
        infoButton.setForeground(Color.BLACK);
        infoButton.setFont(new Font("Arial", Font.BOLD, 16));
        infoButton.setFocusPainted(false);
        infoButton.setBorder(BorderFactory.createLineBorder(new Color(255, 69, 0), 2));


        specialtyComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedSpecialty = (String) specialtyComboBox.getSelectedItem();
                if (selectedSpecialty != null) {

                    String[] doctors = specialtyDoctors.get(selectedSpecialty);
                    doctorComboBox.removeAllItems();
                    for (String doctor : doctors) {
                        doctorComboBox.addItem(doctor);
                    }

                    if (doctors.length > 0) {
                        doctorComboBox.setSelectedIndex(0);
                        String firstDoctor = doctors[0];
                        updateDoctorDetails(firstDoctor);
                    } else {

                        photoLabel.setIcon(null);
                        contactNumberLabel.setText("Contact: ");
                        timeComboBox.removeAllItems();
                    }
                }
            }
        });

        doctorComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String selectedDoctor = (String) doctorComboBox.getSelectedItem();
                if (selectedDoctor != null) {
                    updateDoctorDetails(selectedDoctor);
                }
            }
        });


        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 1;
        add(photoLabel, gbc);

        gbc.gridx = 1; gbc.gridy = 0; gbc.gridwidth = 1;
        add(specialtyLabel, gbc);
        gbc.gridx = 2; gbc.gridy = 0; add(specialtyComboBox, gbc);

        gbc.gridx = 1; gbc.gridy = 1; add(doctorLabel, gbc);
        gbc.gridx = 2; gbc.gridy = 1; add(doctorComboBox, gbc);

        gbc.gridx = 1; gbc.gridy = 2; add(timeLabel, gbc);
        gbc.gridx = 2; gbc.gridy = 2; add(timeComboBox, gbc);

        gbc.gridx = 1; gbc.gridy = 3; add(dateLabel, gbc);
        gbc.gridx = 2; gbc.gridy = 3; add(dateSpinner, gbc);

        gbc.gridx = 1; gbc.gridy = 4; gbc.gridwidth = 2; add(bookButton, gbc);

        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 3; add(contactNumberLabel, gbc);

        gbc.gridx = 2; gbc.gridy = 6; gbc.anchor = GridBagConstraints.NORTHEAST;
        add(infoButton, gbc);


        bookButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String doctor = (String) doctorComboBox.getSelectedItem();
                String specialty = (String) specialtyComboBox.getSelectedItem();
                String time = (String) timeComboBox.getSelectedItem();

                if (doctor == null || specialty == null || time == null) {
                    JOptionPane.showMessageDialog(DoctorViewPage.this, "Please ensure all fields are selected.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                String formattedTime = convertTo24HourFormat(time);
                String date = new SimpleDateFormat("yyyy-MM-dd").format(dateSpinner.getValue());

                System.out.println("Navigating to AppointmentFillDetailsPage...");
                SwingUtilities.invokeLater(() -> {
                    new AppointmentFillDetailsPage(doctor, specialty, formattedTime, date);
                    dispose();
                });
            }
        });



        infoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new SpecialistInfoPage();
                dispose();
            }
        });

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        setVisible(true);
    }
    private String convertTo24HourFormat(String time) {
        try {

            SimpleDateFormat inputFormat = new SimpleDateFormat("hh:mm a");

            SimpleDateFormat outputFormat = new SimpleDateFormat("HH:mm:ss");

            return outputFormat.format(inputFormat.parse(time));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    private void updateDoctorDetails(String doctor) {

        timeComboBox.removeAllItems();
        String[] availableTimes = doctorAvailability.get(doctor);
        if (availableTimes != null) {
            for (String time : availableTimes) {
                timeComboBox.addItem(time);
            }
        }

        ImageIcon newPhotoIcon = loadImageAndResize(doctorImagePaths.get(doctor), 150, 150);
        photoLabel.setIcon(newPhotoIcon);
        contactNumberLabel.setText("Contact: " + doctorContactNumbers.get(doctor));
    }

    private ImageIcon loadImageAndResize(String imagePath, int width, int height) {
        try {
            BufferedImage bufferedImage = ImageIO.read(new File(imagePath));
            Image scaledImage = bufferedImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            return new ImageIcon(scaledImage);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DoctorViewPage());
    }
}
